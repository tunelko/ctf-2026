from urllib.parse import urlparse
from flask import Flask, request, make_response

app = Flask(__name__)
FORBIDDEN_CHARS = ['"',"'",";",",","\n","\r","<",">"]

def validate_url(url):
    try:
        if any(c in url for c in FORBIDDEN_CHARS):
            return None
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            return None
        if not parsed.netloc:
            return None
        return parsed
    except Exception:
        return None


@app.route("/")
def home():
    allowed_hostname = request.args.get("domain", None)
    
    parsed_url = validate_url(allowed_hostname)
    csp_domain_frame = "frame-ancestors "
    if parsed_url is not None:
        csp_domain_frame += "https://"+parsed_url.hostname.encode("idna").decode()
    else:
        csp_domain_frame += "'none'"
        

    html = f"""
        <!doctype html>
        <html>
        <head>
        <meta charset="utf-8">
        <title>Forbidden Script Ritual</title>

        <style>
        body {{
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: radial-gradient(circle at center, #1a0000 0%, #000000 80%);
            color: #ff4d4d;
            font-family: "Courier New", monospace;
            text-shadow: 0 0 10px rgba(255,0,0,0.8);
        }}

        .container {{
            text-align: center;
            padding: 40px;
            border: 1px solid rgba(255,0,0,0.4);
            box-shadow: 0 0 30px rgba(255,0,0,0.4);
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(4px);
        }}

        h1 {{
            font-size: 3rem;
            margin-bottom: 20px;
            letter-spacing: 2px;
        }}

        p {{
            font-size: 1.6rem;
        }}
        </style>

        </head>

        <body>

        <div class="container">
        <h1>Forbidden</h1>
        <p>Have you compete the ritual ? ...</p>
        </div>
        <script>
            const allow_domain = "{csp_domain_frame}";
            console.log("[DEBUG] Added to csp: "+allow_domain);
        </script>
        </body>
        </html>
    """

    response = make_response(html)

    
    response.headers["Content-Security-Policy"] = f"{csp_domain_frame} ; script-src 'self';"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

    return response


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
