process.env.HOME = "/tmp";

const { delay, handleTargetCreated, handleTargetDestroyed, logMainInfo, logMainError } = require("./utils");
const puppeteer = require("puppeteer");

const tips = ["Every console.log usage on the bot will be sent back to you :)", "There is a small race window (~10ms) when a new tab is opened where console.log won't return output :("];
console.log(`==========\nTips: ${tips[Math.floor(Math.random() * tips.length)]}\nPlease note that your exploit must target ${process.env.CHALLENGE_HOST}, as the flag cookie is declared only for this domain.\n==========`);

async function goto(url) {
	logMainInfo("Starting the browser...");
	const browser = await puppeteer.launch({
		headless: "new",
		ignoreHTTPSErrors: true,
		args: [
			"--no-sandbox",
			"--disable-gpu",
			"--disable-jit",
			"--disable-wasm",
			"--disable-dev-shm-usage"
		],
		executablePath: "/usr/bin/chromium-browser"
	});

	browser.on("targetcreated", handleTargetCreated.bind(browser));
	browser.on("targetdestroyed", handleTargetDestroyed.bind(browser));

	const [page] = await browser.pages();
	await handleTargetCreated(page.target());
	await page.setDefaultNavigationTimeout(5000);

	logMainInfo("The bot is visiting the main page...");
	await page.goto(process.env.CHALLENGE_HOST);
	logMainInfo("Setting the flag in a cookie...")
	await page.setCookie({
		name: 'FLAG',
		value: process.env.FLAG,
		domain: new URL(process.env.CHALLENGE_HOST).host
	});

	logMainInfo("Going to the user provided link...");
	try { await page.goto(url) } catch {}
	await delay(3000);

	logMainInfo("Leaving o/");
	await browser.close();
	return;
}

process.stdin.on("data", (data) => {
	const url = data.toString().trim();

	if (!url || !(url.startsWith("http://") || url.startsWith("https://"))) {
		logMainError("You provided an invalid URL. It should start with http:// or https://.");
		process.exit(1);
	}

	goto(url)
	.then(() => process.exit(0))
	.catch((error) => {
		if (process.env.ENVIRONMENT === "development") {
			console.error(error);
		}
		process.exit(1);
	});
});