document.addEventListener('DOMContentLoaded', () => {
    const flanPlayerName = window.flanPlayerName || 'Player';
    const flanOpponentName = window.flanOpponentName || 'Opponent';

    const hasFlash = new URLSearchParams(window.location.search).get('flash') === '1';

    const flanItems = document.querySelectorAll('.flan-item');
    flanItems.forEach(item => {
        item.classList.add('wobble-active');
    });

    const fightButton = document.querySelector('#fight-form button');
    if (fightButton) {
        fightButton.classList.add('wobble-active');
    }

    const fightMessage = document.getElementById('fight-message');
    const flanArena = document.getElementById('flan-arena');

    if (fightMessage && flanArena) {
        flanArena.style.display = 'block';

        const flan1 = document.createElement('div');
        flan1.classList.add('animated-flan', 'flan-left');
        flan1.innerHTML = '🍮<span>' + flanPlayerName + '</span>';
        flanArena.appendChild(flan1);

        const flan2 = document.createElement('div');
        flan2.classList.add('animated-flan', 'flan-right');
        flan2.innerHTML = '🍮<span>' + flanOpponentName + '</span>';
        flanArena.appendChild(flan2);

        fightMessage.style.backgroundColor = '#ffc0cb';
        fightMessage.style.border = '5px solid #ff0000';
        fightMessage.style.padding = '20px';
        fightMessage.style.borderRadius = '10px';
        fightMessage.style.maxWidth = '600px';
        fightMessage.style.margin = '20px auto';
        fightMessage.animate([
            { transform: 'scale(1)' },
            { transform: 'scale(1.05) rotate(-2deg)', offset: 0.5 },
            { transform: 'scale(1)', offset: 1.0 }
        ], {
            duration: 3000,
            iterations: 1
        });

        setTimeout(() => {
            flanArena.innerHTML = '';
            flanArena.style.display = 'none';
        }, 10000);
    }

    const messages = document.querySelectorAll('.message');
    messages.forEach(msg => {
        msg.style.padding = '10px';
        msg.style.borderRadius = '5px';
        msg.style.fontWeight = 'bold';
        msg.style.marginBottom = '15px';

        if (msg.classList.contains('error')) {
            msg.style.backgroundColor = '#ffcccc';
            msg.style.color = '#8b0000';
        } else if (msg.classList.contains('success')) {
            msg.style.backgroundColor = '#ccffcc';
            msg.style.color = '#006400';
        } else if (msg.classList.contains('info')) {
            msg.style.backgroundColor = '#ccccff';
            msg.style.color = '#00008b';
        }

        msg.animate([
            { opacity: 0.5 },
            { opacity: 1.0 }
        ], {
            duration: 300,
            iterations: 3
        });
    });

    if (hasFlash) {
        setTimeout(() => {
            const url = new URL(window.location.href);
            url.searchParams.delete('flash');
            history.replaceState({}, document.title, url.toString());
        }, 500);
    }
});