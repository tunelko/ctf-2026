<?php

ob_start();

require_once 'functions.php';

session_start();

define('CLASH_DIR', 'records');
$CLASH_DIR = CLASH_DIR;

if (!is_dir(CLASH_DIR)) {
    mkdir(CLASH_DIR, 0777, true);
}

spl_autoload_register(function ($className) {
    $file = $className . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

if (is_bad($_COOKIE["flans"])) {
    die("No cooking here!");
}

if (getParam("baker_name") && empty($_SESSION['baker_name'])) {
    $bakerName = trim(getParam("baker_name"));
    if (!empty($bakerName)) {
        $_SESSION['baker_name'] = $bakerName;
        $baker = Baker::load($bakerName) ?? new Baker($bakerName);
        $baker->saveToCookie();
    }
}

if (getParam("flan_name") && isset($_SESSION['baker_name'])) {
    $bakerName = $_SESSION['baker_name'];
    $baker = Baker::load($bakerName);

    if ($baker) {
        $flanName = trim(getParam("flan_name"));

        if (!empty($flanName)) {
            $newFlan = new Flan($flanName);
            $baker->addFlan($newFlan);
            $baker->saveToCookie();
            reload("🍮 Flan {$flanName} created successfully!", 1);
        } else {
            reload("⚠️ Please enter valid values for the flan.", 0);
        }
    }
}

if (getParam("action") === 'fight' && isset($_SESSION['baker_name'])) {
    $bakerName = $_SESSION['baker_name'];
    $baker = Baker::load($bakerName);

    $playerFlans = $baker->getFlans();
    if (count($playerFlans) > 0) {
        $flan_player = $playerFlans[rand(0, count($playerFlans) - 1)];
        $flan_opponent = new Flan("");

        $clash = battleFlans($flan_player, $flan_opponent);
        $baker->recordClash($clash);

        $_SESSION['clash_flan_player'] = $flan_player->getName();
        $_SESSION['clash_flan_opponent'] = $flan_opponent->getName();

        $summaryHtml = "
        <div id='fight-message'>
        ⚔️ NEW CLASH ⚔️
        </div>
        ";

        reload($summaryHtml, 2, "&flash=1");

    } else {
        reload("⚠️ You don't have any flans to fight!", 0);
    }
}

$flanPlayerName = json_encode($_SESSION['clash_flan_player'] ?? 'Player');
$flanOpponentName = json_encode($_SESSION['clash_flan_opponent'] ?? 'Opponent');
unset($_SESSION['clash_flan_player']);
unset($_SESSION['clash_flan_opponent']);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clash of Flans 🍮⚔️</title>
    <link rel="stylesheet" href="main.css">
</head>

<body class="<?= getParam('flash') ? 'screen-shake' : '' ?>">

    <?php
    if (getParam('flash')) {
        echo '<div class="flash"></div>';
    }

    echo "<h1>Clash of Flans 🍮</h1>";

    if (!isset($_SESSION['baker_name'])) {
        echo "<h2>Step 1: Welcome! What is your Baker name?</h2>";
        echo "<form method='POST'>
              Name : <input type='text' name='baker_name' required>
              <button type='submit'>Begin your adventure</button>
          </form>";

    } else {
        $bakerName = $_SESSION['baker_name'];
        $baker = Baker::load($bakerName);

        if (!$baker) {
            session_destroy();
            reload("Error loading player.", 0);
        }

        echo "<h2 id='baker-greeting'>Hello {$baker->getName()}!</h2>";
        $flansCount = count($baker->getFlans());

        echo "<h3>Your Flans ({$flansCount}) :</h3>";
        if ($flansCount === 0) {
            echo "<p>You don't have a flan yet. Create one to get started!</p>";
        } else {
            echo "<ul>";
            foreach ($baker->getFlans() as $flan) {
                echo "<li class='flan-item'>🍮 {$flan->getName()} (Size: {$flan->getSize()}cm, Weight: {$flan->getWeight()}g, Sturdiness: {$flan->getSturdiness()})</li>";
            }
            echo "</ul>";
        }

        echo "<h3>Step 2: Create a new Flan</h3>";
        echo "<form method='POST'>
              Name : <input type='text' name='flan_name' required><br>
              <button type='submit'>Create my Flan</button>
          </form>";

        if ($flansCount > 0) {
            echo "<h3>Step 3: Start a Clash!</h3>";
            echo "<form method='POST' id='fight-form'>
                  <input type='hidden' name='action' value='fight'>
                  <button type='submit'>Battle an Opponent Flan! 💥</button>
              </form>";
        }

        echo "<div id='flan-arena'></div>";

        if (isset($baker)) {
            echo "<h3>Match History</h3>";
            $historyUuids = Baker::getHistoryUuids();

            if (empty($historyUuids)) {
                echo "<p>No matches played yet.</p>";
            } else {
                echo "<ul>";
                foreach ($historyUuids as $uuid) {
                    $summary = Baker::getClashSummaryByUuid($uuid);
                    echo "<li class='clash-history-item'>";
                    echo "<span style='font-weight: bold; color: #ff0000; font-size: 1.1em;'>Combat " . substr($uuid, 0, 8) . "</span>";
                    echo "<br>";
                    echo "<span>" . $summary . "</span>";
                    echo "</li>";
                }
                echo "</ul>";
            }
        }

        if (getParam("e")) {
            echo "<p class='message error'>" . getParam("e") . "</p>";
        }
        if (getParam("s")) {
            echo "<p class='message success'>" . getParam("s") . "</p>";
        }
        if (getParam("i")) {
            echo getParam("i");
        }
    }
    ?>

    <script>
        window.flanPlayerName = JSON.parse('<?= $flanPlayerName ?>');
        window.flanOpponentName = JSON.parse('<?= $flanOpponentName ?>');
    </script>

    <script src="main.js"></script>
</body>

</html>

<?php
ob_end_flush();
?>