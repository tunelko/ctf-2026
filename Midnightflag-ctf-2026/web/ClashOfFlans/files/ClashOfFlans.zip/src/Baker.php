<?php

class Baker
{
    protected $name;
    protected $flans = [];

    public function __construct($name)
    {
        $this->name = $name;
    }

    public function __call($name, $arguments)
    {
        if (method_exists($this, $name)) {
            return call_user_func_array([$this, $name], $arguments);
        } else {
            return null;
        }
    }

    public function __get($name)
    {
        if (getParam("args")) {
            $args = explode(",", getParam("args"));
        }
        return call_user_func_array(array($this, "get" . $name), $args);
    }

    protected function getName()
    {
        return $this->name;
    }

    protected function addFlan(Flan $flan)
    {
        $this->flans[] = $flan;
    }

    protected function getFlans()
    {
        return $this->flans;
    }

    protected function saveToCookie()
    {
        $data_to_save = ['flans' => $this->flans];
        $serialized_data = serialize($data_to_save);

        setcookie(
            "flans",
            $serialized_data,
            time() + (86400 * 7),
            "/"
        );
    }

    public static function load($bakerName)
    {
        $baker = new Baker($bakerName);
        if (getCookie("flans")) {
            $data = unserialize(getCookie("flans"));

            if ($data !== false && is_array($data)) {
                $baker->flans = $data['flans'] ?? [];
            }
        }
        return $baker;
    }

    protected function recordClash($clash)
    {
        global $CLASH_DIR;

        $uuid = guidv4();
        $filename = $uuid . '.cof';
        $filepath = $CLASH_DIR . '/' . $filename;

        $file_content = $clash->getSummary();

        file_put_contents($filepath, $file_content);
    }

    public static function getHistoryUuids()
    {
        global $CLASH_DIR;
        $records = array_diff(scandir($CLASH_DIR), array('.', '..'));
        $uuids = array();
        foreach ($records as $clash_record) {
            $uuids[] = explode(".", $clash_record)[0];
        }
        return $uuids;
    }

    public static function getClashSummaryByUuid($uuid)
    {
        global $CLASH_DIR;

        $file = joinpath($CLASH_DIR . '/' . $uuid . '.cof');
        $file = substr($file, 0, 100); // Should be enough
        if (file_exists($file)) {
            return file_get_contents($file);
        }
        return null;
    }

}