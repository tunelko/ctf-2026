<?php

class Flan
{
    protected $name;
    protected $size;
    protected $weight;
    protected $sturdiness;

    public function __construct($name)
    {
        $this->name = $name ? $name : $this->getRandomFlanName();
        $this->size = 0;
        $this->weight = 0;
        $this->bake();
        $this->sturdiness = (int) round(($this->size * 0.5) + ($this->weight * 0.1));
    }

    public function __destruct()
    {
        echo "<!--Flan {$this->name} may be out of date.-->\n";
    }

    protected function bake()
    {
        $this->size = mt_rand(1, 10);
        $this->weight = mt_rand(1, 5);
    }

    public function getName()
    {
        return $this->name;
    }
    public function getSize()
    {
        return $this->size;
    }
    public function getWeight()
    {
        return $this->weight;
    }
    public function getSturdiness()
    {
        return $this->sturdiness;
    }
    protected function getRandomFlanName()
    {
        $defaultNames = [
            'Noël Flan-tier',
            'Flan-boyant',
            'Époustou-flan',
            'Flan-bant-neuf',
            'Flanprix',
            'Capitaine Flan',
            'Flan-beau-électrique',
            'Flan-boisier',
            'Flan-bec',
            'Flan-tastique',
            'Élé-flan'
        ];
        $randomIndex = array_rand($defaultNames);
        return $defaultNames[$randomIndex];
    }
}