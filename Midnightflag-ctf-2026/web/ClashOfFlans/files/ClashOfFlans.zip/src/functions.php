<?php

if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return (string)$needle !== '' && strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

function flatten($param)
{
    if (is_array($param)) {
        return implode(",", $param);
    } else {
        return $param;
    }
}

function getCookie($name)
{
    $value = null;
    if (isset($_COOKIE[$name])) {
        $value = $_COOKIE[$name];
    }
    return flatten($value);
}

function getParam($name)
{
    $value = null;
    if (isset($_GET[$name])) {
        $value = $_GET[$name];
    } else if (isset($_POST[$name])) {
        $value = $_POST[$name];
    }
    return flatten($value);
}

function is_bad($param)
{
    $blacklist = array(
        'Clash',
        'Baker'
    );

    foreach ($blacklist as $word) {
        if (strpos($param, $word) != false) {
            return true;
        }
    }
    return false;
}

function guidv4($data = null)
{
    $data = $data ?? random_bytes(16);
    assert(strlen($data) == 16);

    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function battleFlans(Flan $flan1, Flan $flan2)
{
    $power1 = $flan1->getSturdiness() + mt_rand(1, 10);
    $power2 = $flan2->getSturdiness() + mt_rand(1, 10);

    $winner = null;
    $details = '';

    if ($power1 > $power2) {
        $winner = $flan1;
        $details = "The flan {$flan1->getName()} (Power: {$power1}) crushed {$flan2->getName()} (Power: {$power2})!";
    } elseif ($power2 > $power1) {
        $winner = $flan2;
        $details = "The flan {$flan2->getName()} (Power: {$power2}) defeated {$flan1->getName()} (Power: {$power1})!";
    } else {
        $winner = ($flan1->getSize() > $flan2->getSize()) ? $flan1 : $flan2;
        $details = "Equal power ({$power1} vs {$power2})! Size decided the match, {$winner->getName()} wins.";
    }
    return new Clash($flan1, $flan2, $winner->getName(), $details);
}

function joinpath(string $path): string
{
    $path = preg_replace('#/{2,}#', '/', $path);
    $path = preg_replace('#\.{3,}#', '..', $path);
    $path = preg_replace('#/(\./)+#', '/', $path);
    $path = trim($path, '/'); 

    $segments = explode('/', $path);
    $stack = [];

    foreach ($segments as $segment) {
        if ($segment === '..') {
            if (!empty($stack) && end($stack) !== '..') {
                array_pop($stack);
            } else {
                $stack[] = '..';
            }
        } elseif ($segment !== '' && $segment !== '.') {
            $stack[] = $segment;
        }
    }
    
    $normalizedPath = implode('/', $stack);
    
    return $normalizedPath;
}

function reload($message = "", $type = 0, $other = "")
{
    if (!empty($message)) {
        switch ($type) {
            case 0:
                $message = "e=" . urlencode($message);
                break;
            case 1:
                $message = "s=" . urlencode($message);
                break;
            case 2:
                $message = "i=" . urlencode($message);
                break;
        }
    }
    header("Location: ?" . $message . $other);
    exit();
}