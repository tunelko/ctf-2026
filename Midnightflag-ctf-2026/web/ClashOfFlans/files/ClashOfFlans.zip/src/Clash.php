<?php

class Clash
{
    protected $flan1;
    protected $flan2;
    protected $winnerName;
    protected $resultDetails;

    public function __construct($flan1, $flan2, $winnerName, $details)
    {
        $this->flan1 = $flan1;
        $this->flan2 = $flan2;
        $this->winnerName = $winnerName;
        $this->resultDetails = $details;
    }

    public function __toString()
    {
        return $this->getSummary();
    }

    public function getSummary()
    {
        $side = getParam("side");
        $side = $side ? $this->flan1->$side : "red";
        return "Clash: {$this->flan1->getName()} ({$side} side) vs {$this->flan2->getName()} | Winner: {$this->winnerName} | Details: {$this->resultDetails}";
    }
    protected function getWinnerName()
    {
        return $this->winnerName;
    }
}