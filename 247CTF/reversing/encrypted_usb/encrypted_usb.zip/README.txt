Urgent Incident Response help needed!

We have been contacted by a key client, whose external storage devices have all been encrypted by some new and unknown ransomware variant.

Important files which have not been backed up have been encrypted and the client needs access to the files from 1 specific device urgently.

The drive uses BitLocker encryption; however, it was mounted at the time of the attack.

The client will not disclose their BitLocker password; however, we do have access to the BitLocker recovery keys from the asset management team.

Unfortunately, the asset management team didn’t map the recovery keys to specific devices, so we only have a company-wide dump.

The external storage device image (encrypted_usb.dd) and BitLocker recovery key dump (recovery_keys_dup.txt) are attached.

Can you help?
