#[allow(lint(public_random))]
module solution::solution {
    use sui::coin::{Self, Coin};
    use sui::dynamic_object_field as dof;
    use sui::random::Random;
    use challenge::card::{Self, Card};
    use challenge::casino_coin::CASINO_COIN;
    use challenge::exchange::{Self, CasinoExchange};
    use challenge::house::{Self, House};

    // Split off `amount` from coin and transfer to sender
    public entry fun split_coin(coin: &mut Coin<CASINO_COIN>, amount: u64, ctx: &mut TxContext) {
        let split = coin::split(coin, amount, ctx);
        transfer::public_transfer(split, tx_context::sender(ctx));
    }

    // Fold: play empty hand to end round without using cards
    public entry fun fold(house: &mut House, ctx: &mut TxContext) {
        let cards = vector::empty<Card>();
        house::play_hand(house, cards, ctx);
    }
}
