#[allow(duplicate_alias, unused_use)]
module challenge::card {

    use std::option;
    use std::string::String;
    use sui::object;
    use sui::tx_context::TxContext;

    public struct Card has key, store {
        id: UID,
        color: String,
        value: u64,
        assignee: Option<address>,
    }

    public fun create_card(
        color: String,
        value: u64,
        assignee: Option<address>,
        ctx: &mut TxContext,
    ): Card {
        Card {
            id: object::new(ctx),
            color,
            value,
            assignee: assignee,
        }
    }

    public fun get_info(card: &Card): (String, u64) {
        (card.color, card.value)
    }

    public fun id(card: &Card): ID {
        object::uid_to_inner(&card.id)
    }

    public fun value(card: &Card): u64 {
        card.value
    }

    public fun set_assignee(card: &mut Card, addr: address) {
        card.assignee = option::some(addr);
    }

    public fun clear_assignee(card: &mut Card) {
        card.assignee = option::none();
    }

    public fun burn(card: Card) {
        let Card { id, color: _, value: _, assignee: _ } = card;
        object::delete(id);
    }
}
