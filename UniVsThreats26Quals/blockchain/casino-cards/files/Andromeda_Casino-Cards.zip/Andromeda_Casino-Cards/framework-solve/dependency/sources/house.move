#[allow(duplicate_alias, unused_use, unused_variable, unused_mut_ref, unused_trailing_semi, lint(public_entry))]
module challenge::house {

    use std::option::Self;
    use std::string::utf8;
    use std::vector;
    use sui::balance::{Self as balance, Balance};
    use sui::coin::{Self as coin, Coin};
    use sui::dynamic_object_field as dof;
    use sui::object::{Self, ID, UID};
    use sui::random::{Self as random, Random, RandomGenerator};
    use sui::transfer;
    use sui::tx_context::{Self, TxContext};

    use challenge::card::{Self as card, Card, burn, clear_assignee, create_card, id, set_assignee, value};
    use challenge::casino_coin::CASINO_COIN;

    const SUI_RANDOM_OBJECT_ADDRESS: address = @0x8;

    public struct House has key {
        id: UID,
        balance: Balance<CASINO_COIN>,
        is_round_running: bool,
        is_round_won: bool,
        random_id: ID,
        cards: vector<ID>,
    }

    const ROUND_FEE: u64 = 10;
    const EROUND_ALREADY_RUNNING: u64 = 1;
    const EINVALID_HAND_SIZE: u64 = 2;
    const EINVALID_RANDOM_OBJECT: u64 = 3;

    fun mint_cards(luck: u64, g: &mut RandomGenerator, ctx: &mut TxContext): vector<Card> {
        let mut v = vector::empty<Card>();
        let mut i = 0u64;
        while (i < 4) {
            let val = random::generate_u64_in_range(g, luck, luck + 3);
            let color = if (i % 2 == 0) { utf8(b"infrared") } else { utf8(b"vantablack") };
            vector::push_back(&mut v, create_card(color, val, option::none(), ctx));
            i = i + 1;
        };
        v
    }

    fun assign_cards(
        mut cards: vector<Card>,
        assignee: address,
        house: &mut House,
        _ctx: &mut TxContext,
    ) {
        let house_addr = object::uid_to_address(&house.id);
        while (!vector::is_empty(&mut cards)) {
            let mut c = vector::pop_back(&mut cards);
            card::set_assignee(&mut c, assignee);
            if (assignee == house_addr) {
                let cid = card::id(&c);
                dof::add<ID, Card>(&mut house.id, cid, c);
                vector::push_back(&mut house.cards, cid);
            } else {
                transfer::public_transfer(c, assignee);
            };
        };
        vector::destroy_empty(cards);
    }

    public fun init_house(bal: Balance<CASINO_COIN>, ctx: &mut TxContext): House {
        House {
            id: object::new(ctx),
            balance: bal,
            is_round_running: false,
            is_round_won: false,
            random_id: object::id_from_address(SUI_RANDOM_OBJECT_ADDRESS),
            cards: vector::empty<ID>(),
        }
    }

    public fun share_house(house: House) {
        transfer::share_object(house);
    }

    public fun unassign_cards(house: &mut House, _ctx: &mut TxContext) {
        let mut i = 0u64;
        let len = vector::length(&house.cards);
        while (i < len) {
            let cid = *vector::borrow(&house.cards, i);
            let c = dof::borrow_mut<ID, Card>(&mut house.id, cid);
            card::clear_assignee(c);
            i = i + 1;
        };
    }

    fun set_round_won(house: &mut House) {
        house.is_round_won = true;
    }

    entry fun start_round(
        house: &mut House,
        payment: Coin<CASINO_COIN>,
        r: &Random,
        ctx: &mut TxContext,
    ) {
        assert!(object::id(r) == house.random_id, EINVALID_RANDOM_OBJECT);
        assert!(!house.is_round_running, EROUND_ALREADY_RUNNING);
        assert!(coin::value(&payment) >= ROUND_FEE, 0);
        let pay_bal = coin::into_balance(payment);
        balance::join(&mut house.balance, pay_bal);

        let mut generator = random::new_generator(r, ctx);
        let player = tx_context::sender(ctx);
        let player_cards = mint_cards(0, &mut generator, ctx);
        let house_cards = mint_cards(10, &mut generator, ctx);

        assign_cards(player_cards, player, house, ctx);
        assign_cards(house_cards, object::uid_to_address(&house.id), house, ctx);

        house.is_round_running = true;
    }

    public entry fun play_hand(
        house: &mut House,
        mut cards: vector<Card>,
        ctx: &mut TxContext,
    ) {
        let n = vector::length(&cards);
        assert!(!(n > 0 && n < 4), EINVALID_HAND_SIZE);

        let mut player_sum = 0u64;
        let mut i = 0u64;
        while (i < n) {
            let card = vector::borrow(&cards, i);
            player_sum = player_sum + card::value(card);
            i = i + 1;
        };

        let mut house_sum = 0u64;
        let len = vector::length(&house.cards);
        i = 0u64;
        while (i < len) {
            let cid = *vector::borrow(&house.cards, i);
            let card = dof::borrow<ID, Card>(&house.id, cid);
            house_sum = house_sum + card::value(card);
            i = i + 1;
        };

        if (player_sum > house_sum) {
            set_round_won(house);
        };

        unassign_cards(house, ctx);

        while (!vector::is_empty(&mut house.cards)) {
            let cid = vector::pop_back(&mut house.cards);
            let removed_card = dof::remove<ID, Card>(&mut house.id, cid);
            card::burn(removed_card);
        };

        while (!vector::is_empty(&mut cards)) {
            let card = vector::pop_back(&mut cards);
            let cid = card::id(&card);
            dof::add<ID, Card>(&mut house.id, cid, card);
            vector::push_back(&mut house.cards, cid);
        };

        house.is_round_running = false;
        vector::destroy_empty(cards);
    }

    public entry fun claim_rewards(house: &mut House, ctx: &mut TxContext) {
        if (!house.is_round_won) return;
        let bal = balance::withdraw_all(&mut house.balance);
        let c = coin::from_balance(bal, ctx);
        transfer::public_transfer(c, tx_context::sender(ctx));
        house.is_round_won = false;
    }

    public fun get_ID(house: &House): ID {
        object::uid_to_inner(&house.id)
    }

    public fun get_random_id(house: &House): ID {
        house.random_id
    }
}
