#[allow(deprecated_usage)]
module challenge::casino_coin {

    use sui::coin::{Self as coin, TreasuryCap};

    public struct CASINO_COIN has drop {}

    public struct TreasuryHolder has key {
        id: UID,
        cap: Option<TreasuryCap<CASINO_COIN>>,
    }

    fun init(otw: CASINO_COIN, ctx: &mut TxContext) {
        let (treasury_cap, metadata) = coin::create_currency<CASINO_COIN>(
            otw,
            0,
            b"CASINO",
            b"Casino Coin",
            b"CTF casino coin",
            option::none(),
            ctx,
        );
        transfer::public_freeze_object(metadata);

        let holder = TreasuryHolder {
            id: object::new(ctx),
            cap: option::some(treasury_cap),
        };
        transfer::share_object(holder);
    }

    public fun take_treasury_cap(holder: &mut TreasuryHolder): TreasuryCap<CASINO_COIN> {
        option::extract(&mut holder.cap)
    }

    public fun has_cap(holder: &TreasuryHolder): bool {
        option::is_some(&holder.cap)
    }
}
