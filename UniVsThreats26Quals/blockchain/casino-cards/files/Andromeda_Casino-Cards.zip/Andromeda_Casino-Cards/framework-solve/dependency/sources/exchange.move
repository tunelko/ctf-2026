#[allow(duplicate_alias, unused_variable, lint(public_entry))]
module challenge::exchange {

    use std::option::Self;
    use sui::balance::{Self as balance, Balance};
    use sui::coin::{Self as coin, Coin, TreasuryCap};
    use sui::object::{Self, ID, UID};
    use sui::transfer;
    use sui::tx_context::{Self, TxContext};

    use challenge::casino_coin::{CASINO_COIN, TreasuryHolder};
    use challenge::house;

    const FREE_AMOUNT: u64 = 100;
    const SOLVE_AMOUNT: u64 = 150;
    const HOUSE_INITIAL: u64 = 50;

    public struct CasinoExchange has key {
        id: UID,
        treasury_cap: TreasuryCap<CASINO_COIN>,
        claim_balance: Balance<CASINO_COIN>,
        house_id: Option<ID>,
        is_solved: bool,
    }

    public fun create_challenge(holder: &mut TreasuryHolder, ctx: &mut TxContext) {
        assert!(challenge::casino_coin::has_cap(holder), 0);
        let mut treasury_cap = challenge::casino_coin::take_treasury_cap(holder);

        let claim_bal = coin::mint_balance(&mut treasury_cap, FREE_AMOUNT);
        let house_bal = coin::mint_balance(&mut treasury_cap, HOUSE_INITIAL);

        let house = house::init_house(house_bal, ctx);
        let house_id = house::get_ID(&house);
        house::share_house(house);

        let exchange = CasinoExchange {
            id: object::new(ctx),
            treasury_cap,
            claim_balance: claim_bal,
            house_id: option::some(house_id),
            is_solved: false,
        };
        transfer::share_object(exchange);
    }

    public entry fun claim_coin(exchange: &mut CasinoExchange, ctx: &mut TxContext) {
        let amount = balance::value(&exchange.claim_balance);
        if (amount == 0) return;
        let take_amount = if (amount >= FREE_AMOUNT) { FREE_AMOUNT } else { amount };
        let bal = balance::split(&mut exchange.claim_balance, take_amount);
        let c = coin::from_balance(bal, ctx);
        transfer::public_transfer(c, tx_context::sender(ctx));
    }

    public entry fun solve(exchange: &mut CasinoExchange, payment: Coin<CASINO_COIN>, _ctx: &mut TxContext) {
        let amount = coin::value(&payment);
        if (amount >= SOLVE_AMOUNT) {
            exchange.is_solved = true;
        };
        let bal = coin::into_balance(payment);
        balance::join(&mut exchange.claim_balance, bal);
    }

    public fun is_solved(exchange: &CasinoExchange): bool {
        exchange.is_solved
    }

    public fun house_id(exchange: &CasinoExchange): Option<ID> {
        exchange.house_id
    }
}
