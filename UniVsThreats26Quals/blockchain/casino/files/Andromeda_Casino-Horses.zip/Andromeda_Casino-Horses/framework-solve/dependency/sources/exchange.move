module challenge::exchange {

    use std::string::utf8;
    use sui::balance::{Self as balance, Balance};
    use sui::coin::{Self as coin, Coin, TreasuryCap};

    use challenge::casino_coin::{CASINO_COIN, TreasuryHolder};
    use challenge::stall;

    const FREE_AMOUNT: u64 = 100;
    const SOLVE_AMOUNT: u64 = 150;
    const BET_STALL_INITIAL: u64 = 50;

    public struct CasinoExchange has key {
        id: UID,
        treasury_cap: TreasuryCap<CASINO_COIN>,
        claim_balance: Balance<CASINO_COIN>,
        bet_stall_id: Option<ID>,
        is_solved: bool,
    }

    public fun create_challenge(holder: &mut TreasuryHolder, ctx: &mut TxContext) {
        assert!(challenge::casino_coin::has_cap(holder), 0);
        let mut treasury_cap = challenge::casino_coin::take_treasury_cap(holder);

        let claim_bal = coin::mint_balance(&mut treasury_cap, FREE_AMOUNT);
        let stall_bal = coin::mint_balance(&mut treasury_cap, BET_STALL_INITIAL);

        let mut st = stall::create_bet_stall(stall_bal, ctx);
        stall::mint_horse(&mut st, utf8(b"Nebula"), utf8(b"brown"), utf8(b"Thoroughbred"), ctx);
        stall::mint_horse(&mut st, utf8(b"Sagittarius"), utf8(b"black"), utf8(b"Appaloosa"), ctx);
        stall::mint_horse(&mut st, utf8(b"Stardust"), utf8(b"gray"), utf8(b"Mustang"), ctx);
        stall::mint_horse(&mut st, utf8(b"Rocket"), utf8(b"white"), utf8(b"Arabian"), ctx);
        stall::mint_horse(&mut st, utf8(b"Ursa"), utf8(b"white"), utf8(b"Appaloosa"), ctx);
        let stall_id = stall::stall_id(&st);
        stall::share_bet_stall(st);

        let exchange = CasinoExchange {
            id: object::new(ctx),
            treasury_cap,
            claim_balance: claim_bal,
            bet_stall_id: option::some(stall_id),
            is_solved: false,
        };
        transfer::share_object(exchange);
    }

    #[allow(lint(self_transfer))]
    public fun claim_coin(exchange: &mut CasinoExchange, ctx: &mut TxContext) {
        let amount = balance::value(&exchange.claim_balance);
        if (amount == 0) return;
        let take_amount = if (amount >= FREE_AMOUNT) { FREE_AMOUNT } else { amount };
        let bal = balance::split(&mut exchange.claim_balance, take_amount);
        let c = coin::from_balance(bal, ctx);
        transfer::public_transfer(c, tx_context::sender(ctx));
    }

    public fun solve(exchange: &mut CasinoExchange, payment: Coin<CASINO_COIN>, _ctx: &mut TxContext) {
        let amount = coin::value(&payment);
        if (amount >= SOLVE_AMOUNT) {
            exchange.is_solved = true;
        };
        let bal = coin::into_balance(payment);
        balance::join(&mut exchange.claim_balance, bal);
    }

    public fun is_solved(exchange: &CasinoExchange): bool {
        exchange.is_solved
    }

    public fun bet_stall_id(exchange: &CasinoExchange): Option<ID> {
        exchange.bet_stall_id
    }
}
