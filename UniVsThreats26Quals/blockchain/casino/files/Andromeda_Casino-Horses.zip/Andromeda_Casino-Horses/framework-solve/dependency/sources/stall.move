module challenge::stall {

    use std::string::{Self as string, String, utf8};
    use sui::balance::{Self as balance, Balance};
    use sui::coin::{Self as coin, Coin};
    use sui::dynamic_object_field as dof;

    use challenge::casino_coin::CASINO_COIN;

    public struct HorseNFT has key, store {
        id: UID,
        name: String,
        speed: u64,
        color: String,
        breed: String,
    }

    public struct BetStall has key {
        id: UID,
        balance: Balance<CASINO_COIN>,
        horses: vector<ID>,
    }

    const MIN_BET_STANDARD: u64 = 50;
    const MIN_BET_PREMIUM: u64 = 120;

    fun create_horse(
        name: String,
        speed: u64,
        color: String,
        breed: String,
        ctx: &mut TxContext,
    ): HorseNFT {
        HorseNFT {
            id: object::new(ctx),
            name,
            speed,
            color,
            breed,
        }
    }

    public fun get_name(horse: &HorseNFT): String {
        horse.name
    }

    public fun get_speed(horse: &HorseNFT): u64 {
        horse.speed
    }

    public fun get_color(horse: &HorseNFT): String {
        horse.color
    }

    public fun get_breed(horse: &HorseNFT): String {
        horse.breed
    }

    public fun id(horse: &HorseNFT): ID {
        object::uid_to_inner(&horse.id)
    }

    public fun create_bet_stall(bal: Balance<CASINO_COIN>, ctx: &mut TxContext): BetStall {
        BetStall {
            id: object::new(ctx),
            balance: bal,
            horses: vector::empty<ID>(),
        }
    }

    public fun share_bet_stall(stall: BetStall) {
        transfer::share_object(stall);
    }

    public fun stall_id(stall: &BetStall): ID {
        object::uid_to_inner(&stall.id)
    }

    public fun is_valid_breed(breed: String): bool {
        let mut breeds = vector::empty<String>();
        vector::push_back(&mut breeds, utf8(b"Thoroughbred"));
        vector::push_back(&mut breeds, utf8(b"Arabian"));
        vector::push_back(&mut breeds, utf8(b"Mustang"));
        vector::push_back(&mut breeds, utf8(b"Appaloosa"));
        let mut i = 0u64;
        let len = vector::length(&breeds);
        let breed_len = string::length(&breed);
        while (i < len) {
            let b = *vector::borrow(&breeds, i);
            if (string::index_of(&breed, &b) < breed_len) return true;
            i = i + 1;
        };
        false
    }

    public fun mint_horse(
        stall: &mut BetStall,
        name: String,
        color: String,
        breed: String,
        ctx: &mut TxContext,
    ) {
        assert!(is_valid_breed(breed), 0);
        let speed = string::length(&breed);
        let horse = create_horse(name, speed, color, breed, ctx);
        let hid = object::uid_to_inner(&horse.id);
        dof::add<ID, HorseNFT>(&mut stall.id, hid, horse);
        vector::push_back(&mut stall.horses, hid);
    }

    public fun get_min_bet(stall: &BetStall, horse_id: ID): u64 {
        if (!has_horse(stall, horse_id)) return MIN_BET_STANDARD;
        let horse = dof::borrow<ID, HorseNFT>(&stall.id, horse_id);
        if (*string::as_bytes(&horse.breed) == b"Thoroughbred") MIN_BET_PREMIUM else MIN_BET_STANDARD
    }

    public fun has_horse(stall: &BetStall, horse_id: ID): bool {
        dof::exists_with_type<ID, HorseNFT>(&stall.id, horse_id)
    }

    fun is_fastest_horse(stall: &BetStall, horse_id: ID): bool {
        let horse = dof::borrow<ID, HorseNFT>(&stall.id, horse_id);
        let speed = horse.speed;
        let mut i = 0u64;
        let len = vector::length(&stall.horses);
        while (i < len) {
            let hid = *vector::borrow(&stall.horses, i);
            let h = dof::borrow<ID, HorseNFT>(&stall.id, hid);
            if (h.speed > speed) return false;
            i = i + 1;
        };
        true
    }

    fun transfer_reward(stall: &mut BetStall, recipient: address, ctx: &mut TxContext) {
        let bal = balance::withdraw_all(&mut stall.balance);
        let c = coin::from_balance(bal, ctx);
        transfer::public_transfer(c, recipient);
    }

    public fun display_horses(stall: &BetStall): String {
        let mut out = utf8(b"");
        let mut i = 0u64;
        let len = vector::length(&stall.horses);
        while (i < len) {
            let hid = *vector::borrow(&stall.horses, i);
            let horse = dof::borrow<ID, HorseNFT>(&stall.id, hid);
            string::append(&mut out, horse.name);
            string::append(&mut out, utf8(b" "));
            i = i + 1;
        };
        out
    }

    public fun bet(
        stall: &mut BetStall,
        horse_index: u64,
        payment: Coin<CASINO_COIN>,
        ctx: &mut TxContext,
    ) {
        let horse_id = *vector::borrow(&stall.horses, horse_index);
        let min_bet = get_min_bet(stall, horse_id);
        assert!(coin::value(&payment) >= min_bet, 0);
        let payment_balance = coin::into_balance(payment);
        balance::join(&mut stall.balance, payment_balance);
        if (is_fastest_horse(stall, horse_id)) {
            transfer_reward(stall, tx_context::sender(ctx), ctx);
        };
    }
}
