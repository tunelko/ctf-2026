package com.controlcenter.security;

import com.controlcenter.session.InMemoryIndexedSessionRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Base64;

@Component
@Order(-150)
public class CommandWorkFilter extends OncePerRequestFilter {

    static final int BCRYPT_STRENGTH = 13;
    static final String PEPPER = "CHANGED_ON_REMOTE";

    private final InMemoryIndexedSessionRepository sessionRepo;
    private final BCryptPasswordEncoder            bcrypt;
    private final AccessLog                        accessLog;

    public CommandWorkFilter(InMemoryIndexedSessionRepository sessionRepo, AccessLog accessLog) {
        this.sessionRepo = sessionRepo;
        this.bcrypt      = new BCryptPasswordEncoder(BCRYPT_STRENGTH);
        this.accessLog   = accessLog;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        if (request.getRequestURI().startsWith("/command")) {
            String rawId = resolveSessionId(request);
            if (rawId != null) {
                var session = sessionRepo.findById(rawId);
                if (session != null && "YANKEE_WHITE".equals(session.getAttribute("role"))) {
                    accessLog.record(bcrypt.encode(rawId + PEPPER)); 
                }
            }
        }
        chain.doFilter(request, response);
    }

    private static String resolveSessionId(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return null;
        for (Cookie c : cookies) {
            if ("SESSION".equals(c.getName())) {
                try {
                    String val = c.getValue();
                    int rem = val.length() % 4;
                    if (rem != 0) val = val + "=".repeat(4 - rem);
                    return new String(Base64.getUrlDecoder().decode(val));
                } catch (IllegalArgumentException e) {
                    return c.getValue();
                }
            }
        }
        return null;
    }
}
