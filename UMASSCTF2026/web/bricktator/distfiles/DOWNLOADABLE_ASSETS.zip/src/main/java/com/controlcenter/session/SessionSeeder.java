package com.controlcenter.session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.MapSession;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

@Component
@Profile("!prod")
public class SessionSeeder implements ApplicationRunner {

    private static final Logger   log   = LoggerFactory.getLogger(SessionSeeder.class);
    private static final String[] WORDS = {"Gear", "Sprocket", "Cog", "Spur", "Wheel"};

    private final InMemoryIndexedSessionRepository sessionRepo;
    private final SeederProperties                 props;
    private final SecretsHolder                    secretsHolder;

    public SessionSeeder(InMemoryIndexedSessionRepository sessionRepo,
                         SeederProperties props,
                         SecretsHolder secretsHolder) {
        this.sessionRepo   = sessionRepo;
        this.props         = props;
        this.secretsHolder = secretsHolder;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!props.enabled()) return;

        int total     = props.totalSessions();
        int threshold = props.keyThreshold();

        var secureRng = new SecureRandom();

        long secret = (secureRng.nextLong(SecretSharing.PRIME - 1)) + 1;

        long[] coeffs = SecretSharing.generateCoefficients(secret, threshold, new Random(secureRng.nextLong()));
        secretsHolder.setPolynomialCoefficients(coeffs);

        List<SecretSharing.Share> shares = SecretSharing.fromCoefficients(coeffs, total + 1);

        var rng = secureRng;

        List<Integer> indices = new java.util.ArrayList<>();
        for (int i = 0; i < total; i++) {
            if (i != 0 && i != 4) indices.add(i);
        }
        Collections.shuffle(indices, rng);
        Set<Integer> yankeeWhiteIndices = new HashSet<>(indices.subList(0, 7));

        for (int i = 0; i < total; i++) {
            SecretSharing.Share share = shares.get(i);

            String sessionId = "%05d-%08x".formatted(share.x(), share.y());
            String username  = switch (i) {
                case 0 -> "john_doe";
                case 4 -> "jane_doe";
                default -> WORDS[rng.nextInt(WORDS.length)] + "_" + UUID.randomUUID();
            };
            String role      = yankeeWhiteIndices.contains(i) ? "YANKEE_WHITE" : "Q_CLEARANCE";

            var session = new MapSession(sessionId);
            session.setMaxInactiveInterval(sessionRepo.getDefaultMaxInactiveInterval());

            session.setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, username);
            session.setAttribute("username", username);
            session.setAttribute("role",     role);

            sessionRepo.save(session);
        }

        log.info("YANKEE_WHITE sessions:");
        sessionRepo.findAll().values().stream()
            .filter(s -> "YANKEE_WHITE".equals(s.getAttribute("role")))
            .forEach(s -> log.info("  id={}  user={}", s.getId(), s.getAttribute("username")));

        SecretSharing.Share adminShare = shares.get(total);
        String bricktatorSessionId = "%05d-%08x".formatted(adminShare.x(), adminShare.y());
        var adminSession = new MapSession(bricktatorSessionId);
        adminSession.setMaxInactiveInterval(sessionRepo.getDefaultMaxInactiveInterval());
        adminSession.setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, "bricktator");
        adminSession.setAttribute("username",  "bricktator");
        adminSession.setAttribute("role",      "YANKEE_WHITE");
        sessionRepo.save(adminSession);
    }
}
