package com.controlcenter.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.Instant;

@Controller
public class DashboardController {

    @GetMapping("/")
    public String root() {
        return "redirect:/dashboard";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(
            @AuthenticationPrincipal UserDetails user,
            HttpSession session,
            Model model) {

        model.addAttribute("username", user.getUsername());
        model.addAttribute("roles", user.getAuthorities());
        model.addAttribute("sessionId", session.getId());
        model.addAttribute("sessionCreated", Instant.ofEpochMilli(session.getCreationTime()));
        model.addAttribute("sessionLastAccessed", Instant.ofEpochMilli(session.getLastAccessedTime()));

        return "dashboard";
    }
}
