package com.controlcenter.session;

import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.MapSession;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class InMemoryIndexedSessionRepository
        implements FindByIndexNameSessionRepository<MapSession> {

    private final Map<String, MapSession> sessions = new ConcurrentHashMap<>();
    private Duration defaultMaxInactiveInterval = Duration.ofMinutes(30);

    public void setDefaultMaxInactiveInterval(Duration duration) {
        this.defaultMaxInactiveInterval = duration;
    }

    public Duration getDefaultMaxInactiveInterval() {
        return defaultMaxInactiveInterval;
    }

    @Override
    public MapSession createSession() {
        var session = new MapSession();
        session.setMaxInactiveInterval(defaultMaxInactiveInterval);
        return session;
    }

    @Override
    public void save(MapSession session) {
        sessions.put(session.getId(), new MapSession(session));
    }

    @Override
    public MapSession findById(String id) {
        MapSession session = sessions.get(id);
        if (session == null) return null;
        if (session.isExpired()) {
            deleteById(id);
            return null;
        }
        return new MapSession(session);
    }

    @Override
    public void deleteById(String id) {
        sessions.remove(id);
    }

    public Map<String, MapSession> findAll() {
        return sessions.entrySet().stream()
            .filter(e -> !e.getValue().isExpired())
            .collect(Collectors.toMap(Map.Entry::getKey, e -> new MapSession(e.getValue())));
    }

    @Override
    public Map<String, MapSession> findByIndexNameAndIndexValue(String indexName, String indexValue) {
        if (!PRINCIPAL_NAME_INDEX_NAME.equals(indexName)) {
            return new HashMap<>();
        }
        return sessions.entrySet().stream()
            .filter(e -> !e.getValue().isExpired())
            .filter(e -> indexValue.equals(e.getValue().getAttribute(PRINCIPAL_NAME_INDEX_NAME)))
            .collect(Collectors.toMap(Map.Entry::getKey, e -> new MapSession(e.getValue())));
    }
}
