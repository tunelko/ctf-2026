package com.controlcenter.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
public class AccessLog {

    private static final Logger log = LoggerFactory.getLogger(AccessLog.class);

    public record Entry(Instant timestamp, String sessionHash) {}

    private final List<Entry> entries = Collections.synchronizedList(new ArrayList<>());

    public void record(String sessionHash) {
        entries.add(new Entry(Instant.now(), sessionHash));
    }

    public List<Entry> entries() {
        return Collections.unmodifiableList(entries);
    }

    public boolean verify(String sessionId, String hash) {
        boolean match = org.springframework.security.crypto.bcrypt.BCrypt.checkpw(sessionId, hash);
        log.info("verify sessionId={} match={}", sessionId, match);
        return match;
    }
}
