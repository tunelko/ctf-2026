package com.controlcenter.security;

import com.controlcenter.session.InMemoryIndexedSessionRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.session.MapSession;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;

@Component
public class SessionSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    private static final Map<String, Integer> USER_SESSION_INDEX = Map.of(
        "bricktator", 5001,
        "John_Doe",   1,
        "Jane_Doe",   5
    );

    private final InMemoryIndexedSessionRepository sessionRepo;

    public SessionSuccessHandler(InMemoryIndexedSessionRepository sessionRepo) {
        super("/dashboard");
        this.sessionRepo = sessionRepo;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, jakarta.servlet.ServletException {
        String username = authentication.getName();
        MapSession target = resolveSession(username);

        if (target == null) {
            super.onAuthenticationSuccess(request, response, authentication);
            return;
        }

        SecurityContext ctx = SecurityContextHolder.createEmptyContext();
        ctx.setAuthentication(authentication);
        target.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, ctx);
        sessionRepo.save(target);

        request.setAttribute(SessionIdResolver.PENDING_SESSION_ATTR, target.getId());

        var loginSession = request.getSession(false);
        if (loginSession != null) loginSession.invalidate();

        response.sendRedirect("/dashboard");
    }

    private MapSession resolveSession(String username) {
        Integer index = USER_SESSION_INDEX.get(username);
        if (index == null) return null;
        String idPrefix = "%05d-".formatted(index);
        return sessionRepo.findAll().values().stream()
            .filter(s -> s.getId().startsWith(idPrefix))
            .findFirst()
            .orElse(null);
    }
}
