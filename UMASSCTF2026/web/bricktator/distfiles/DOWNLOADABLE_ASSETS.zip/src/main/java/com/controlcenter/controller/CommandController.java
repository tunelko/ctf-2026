package com.controlcenter.controller;

import com.controlcenter.security.OverrideService;
import com.controlcenter.session.SecretsHolder;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

@Controller
@RequestMapping("/command")
public class CommandController {

    private static final DateTimeFormatter TIMESTAMP =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneOffset.UTC);

    private final OverrideService overrideService;
    private final SecretsHolder   secretsHolder;

    public CommandController(OverrideService overrideService, SecretsHolder secretsHolder) {
        this.overrideService = overrideService;
        this.secretsHolder   = secretsHolder;
    }

    @GetMapping
    public String portal(@AuthenticationPrincipal UserDetails user,
                         HttpSession session,
                         Model model) {
        if (!hasRole(user, "ROLE_YANKEE_WHITE")) return "redirect:/dashboard";
        if (!isValidSession(session.getId())) return "redirect:/dashboard";
        if (!hasRole(user, "ROLE_GOLD_EAGLE"))   return "redirect:/dashboard";

        model.addAttribute("username",  user.getUsername());
        model.addAttribute("roles",     user.getAuthorities());
        model.addAttribute("timestamp", TIMESTAMP.format(Instant.now()) + " UTC");

        model.addAttribute("coreTemp",       "847");
        model.addAttribute("coolantPressure","155");
        model.addAttribute("powerOutput",    "1,247");
        model.addAttribute("controlRod",     "67");
        model.addAttribute("neutronFlux",    "3.41e13");
        model.addAttribute("steamFlow",      "2,180");

        model.addAttribute("sectors", java.util.List.of(
            new Sector("ALPHA", "PRIMARY LOOP",      "NOMINAL",  "green"),
            new Sector("BETA",  "SECONDARY LOOP",    "NOMINAL",  "green"),
            new Sector("GAMMA", "TURBINE HALL",      "NOMINAL",  "green"),
            new Sector("DELTA", "CONTROL ROOM",      "NOMINAL",  "green"),
            new Sector("EPSILON","COOLING TOWER",    "DEGRADED", "amber"),
            new Sector("ZETA",  "WASTE PROCESSING",  "OFFLINE",  "red")
        ));

        model.addAttribute("threatLevel", "ELEVATED");
        model.addAttribute("threatColor", "amber");
        model.addAttribute("threatCode",  2);

        model.addAttribute("personnelOnsite",  312);
        model.addAttribute("personnelEvac",    0);
        model.addAttribute("personnelUnknown", 4);

        model.addAttribute("alerts", java.util.List.of(
            new Alert("WARN", "Cooling tower EPSILON — flow rate 12% below nominal"),
            new Alert("WARN", "Sector ZETA offline — maintenance window active"),
            new Alert("INFO", "Control rod recalibration scheduled 02:00 UTC"),
            new Alert("CRIT", "Unrecognized session cluster detected in session store")
        ));

        return "command";
    }

    @GetMapping("/override")
    public String overridePage(@AuthenticationPrincipal UserDetails user,
                               HttpSession session) {
        if (!hasRole(user, "ROLE_YANKEE_WHITE")) return "redirect:/dashboard";
        if (!isValidSession(session.getId())) return "redirect:/dashboard";
        if (!hasRole(user, "ROLE_GOLD_EAGLE"))   return "redirect:/dashboard";
        return "override";
    }

    @PostMapping("/override")
    public String initiateOverride(@AuthenticationPrincipal UserDetails user,
                                   HttpSession session,
                                   Model model) {
        if (!hasRole(user, "ROLE_YANKEE_WHITE")) return "redirect:/dashboard";
        if (!isValidSession(session.getId())) return "redirect:/dashboard";
        if (!hasRole(user, "ROLE_GOLD_EAGLE"))   return "redirect:/dashboard";
        String token = overrideService.initiate(session.getId());
        model.addAttribute("token",    token);
        model.addAttribute("required", OverrideService.REQUIRED_APPROVALS);
        model.addAttribute("ttlMins",  OverrideService.TTL.toMinutes());
        return "override";
    }

    private boolean isValidSession(String sessionId) {
        String[] parts = sessionId.split("-");
        if (parts.length != 2) return false;
        try {
            int  x = Integer.parseInt(parts[0]);
            long y = Long.parseLong(parts[1], 16);
            return secretsHolder.verifySession(x, y);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean hasRole(UserDetails user, String role) {
        return user != null && user.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals(role));
    }

    public record Sector(String id, String name, String status, String color) {}
    public record Alert(String level, String message) {}
}
