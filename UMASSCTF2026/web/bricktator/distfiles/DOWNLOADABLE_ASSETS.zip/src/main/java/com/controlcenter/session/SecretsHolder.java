package com.controlcenter.session;

import org.springframework.stereotype.Component;

@Component
public class SecretsHolder {

    private volatile long[] polynomialCoefficients = null;

    public void setPolynomialCoefficients(long[] coeffs) {
        this.polynomialCoefficients = coeffs.clone();
    }

    public boolean verifySession(int x, long y) {
        long[] coeffs = this.polynomialCoefficients;
        return coeffs != null && SecretSharing.verify(coeffs, x, y);
    }
}
