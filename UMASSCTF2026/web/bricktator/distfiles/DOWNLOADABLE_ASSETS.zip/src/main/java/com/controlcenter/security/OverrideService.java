package com.controlcenter.security;

import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

@Service
public class OverrideService {

    public static final int      REQUIRED_APPROVALS = 5;
    public static final Duration TTL                = Duration.ofMinutes(10);

    public enum ApprovalResult { INVALID_TOKEN, EXPIRED, ALREADY_APPROVED, APPROVED, COMPLETE, CANCELLED }

    public record OverrideStatus(String token, Instant expiresAt, int approvals, int required) {
        public boolean isExpired() { return Instant.now().isAfter(expiresAt); }
    }

    private final SecureRandom rng = new SecureRandom();

    private volatile String      activeToken;
    private volatile Instant     expiresAt;
    private volatile Set<String> approvedSessionIds;

    public synchronized String initiate(String initiatorSessionId) {
        byte[] bytes = new byte[16];
        rng.nextBytes(bytes);
        activeToken        = bytesToHex(bytes);
        expiresAt          = Instant.now().plus(TTL);
        approvedSessionIds = ConcurrentHashMap.newKeySet();
        approvedSessionIds.add(initiatorSessionId);
        return activeToken;
    }

    public synchronized ApprovalResult approve(String token, String sessionId, Predicate<String> isAuthorized) {
        if (activeToken == null || !activeToken.equals(token)) return ApprovalResult.INVALID_TOKEN;
        if (Instant.now().isAfter(expiresAt))                  { clear(); return ApprovalResult.EXPIRED; }
        if (approvedSessionIds.contains(sessionId))            return ApprovalResult.ALREADY_APPROVED;

        approvedSessionIds.add(sessionId);

        if (approvedSessionIds.size() >= REQUIRED_APPROVALS) {
            boolean allValid = approvedSessionIds.stream().allMatch(isAuthorized);
            clear();
            return allValid ? ApprovalResult.COMPLETE : ApprovalResult.CANCELLED;
        }
        return ApprovalResult.APPROVED;
    }

    public synchronized OverrideStatus getStatus(String token) {
        if (activeToken == null || !activeToken.equals(token)) return null;
        if (Instant.now().isAfter(expiresAt)) { clear(); return null; }
        return new OverrideStatus(activeToken, expiresAt, approvedSessionIds.size(), REQUIRED_APPROVALS);
    }

    public synchronized boolean cancel(String token) {
        if (activeToken == null || !activeToken.equals(token)) return false;
        clear();
        return true;
    }

    private void clear() {
        activeToken        = null;
        expiresAt          = null;
        approvedSessionIds = null;
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
