package com.controlcenter.session;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

@ConfigurationProperties(prefix = "ncc.seeder")
public record SeederProperties(
    @DefaultValue("true")  boolean enabled,
    @DefaultValue("5000")  int totalSessions,
    @DefaultValue("3")     int keyThreshold
) {
    public SeederProperties {
        if (totalSessions <= 0)          throw new IllegalArgumentException("ncc.seeder.total-sessions must be > 0");
        if (keyThreshold < 2)            throw new IllegalArgumentException("ncc.seeder.key-threshold must be >= 2");
        if (keyThreshold > totalSessions) throw new IllegalArgumentException("ncc.seeder.key-threshold cannot exceed total-sessions");
    }
}
