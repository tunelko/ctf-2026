package com.controlcenter.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.session.web.http.CookieHttpSessionIdResolver;
import org.springframework.session.web.http.HttpSessionIdResolver;

import java.util.List;

public class SessionIdResolver implements HttpSessionIdResolver {

    static final String PENDING_SESSION_ATTR = SessionIdResolver.class.getName() + ".PENDING";

    private final CookieHttpSessionIdResolver delegate = new CookieHttpSessionIdResolver();

    @Override
    public List<String> resolveSessionIds(HttpServletRequest request) {
        return delegate.resolveSessionIds(request);
    }

    @Override
    public void setSessionId(HttpServletRequest request, HttpServletResponse response, String sessionId) {
        String pending = (String) request.getAttribute(PENDING_SESSION_ATTR);
        delegate.setSessionId(request, response, pending != null ? pending : sessionId);
    }

    @Override
    public void expireSession(HttpServletRequest request, HttpServletResponse response) {
        String pending = (String) request.getAttribute(PENDING_SESSION_ATTR);
        if (pending != null) {
            delegate.setSessionId(request, response, pending);
        } else {
            delegate.expireSession(request, response);
        }
    }
}
