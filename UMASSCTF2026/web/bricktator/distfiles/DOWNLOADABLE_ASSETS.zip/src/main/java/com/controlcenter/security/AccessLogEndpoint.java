package com.controlcenter.security;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@Endpoint(id = "accesslog")
public class AccessLogEndpoint {

    private final AccessLog accessLog;

    public AccessLogEndpoint(AccessLog accessLog) {
        this.accessLog = accessLog;
    }

    @ReadOperation
    public Map<String, Object> entries() {
        List<AccessLog.Entry> all = accessLog.entries();
        return Map.of(
            "count",   all.size(),
            "entries", all.stream().map(e -> Map.of(
                "timestamp",   e.timestamp().toString(),
                "sessionHash", e.sessionHash()
            )).toList()
        );
    }

}
