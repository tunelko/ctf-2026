package com.controlcenter.config;

import com.controlcenter.security.SessionIdResolver;
import com.controlcenter.session.InMemoryIndexedSessionRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.MapSession;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;
import org.springframework.session.security.SpringSessionBackedSessionRegistry;
import org.springframework.session.web.http.HttpSessionIdResolver;

import java.time.Duration;

@Configuration
@EnableSpringHttpSession
public class SessionConfig {

    @Bean
    public InMemoryIndexedSessionRepository sessionRepository() {
        var repo = new InMemoryIndexedSessionRepository();
        repo.setDefaultMaxInactiveInterval(Duration.ofSeconds(-1));
        return repo;
    }

    @Bean
    public HttpSessionIdResolver httpSessionIdResolver() {
        return new SessionIdResolver();
    }

    @Bean
    public SpringSessionBackedSessionRegistry<MapSession> sessionRegistry(
            FindByIndexNameSessionRepository<MapSession> repo) {
        return new SpringSessionBackedSessionRegistry<>(repo);
    }
}
