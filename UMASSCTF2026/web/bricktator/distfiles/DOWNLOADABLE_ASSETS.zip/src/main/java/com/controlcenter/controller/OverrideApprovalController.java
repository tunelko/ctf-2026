package com.controlcenter.controller;

import com.controlcenter.security.OverrideService;
import com.controlcenter.security.OverrideService.ApprovalResult;
import com.controlcenter.session.InMemoryIndexedSessionRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/override")
public class OverrideApprovalController {

    private static final String FLAG = "UMASS{CHANGED_ON_REMOTE}";

    private final OverrideService                  overrideService;
    private final InMemoryIndexedSessionRepository sessionRepo;

    public OverrideApprovalController(OverrideService overrideService,
                                      InMemoryIndexedSessionRepository sessionRepo) {
        this.overrideService = overrideService;
        this.sessionRepo     = sessionRepo;
    }

    @GetMapping("/{token}")
    public String approvalPage(@PathVariable String token,
                               HttpSession session,
                               Model model) {
        var status = overrideService.getStatus(token);
        if (status == null) {
            model.addAttribute("error", "Token invalid or expired.");
            return "override_approval";
        }

        model.addAttribute("token",     token);
        model.addAttribute("approvals", status.approvals());
        model.addAttribute("required",  status.required());
        model.addAttribute("expiresAt", status.expiresAt());
        return "override_approval";
    }

    @PostMapping("/{token}")
    public String approve(@PathVariable String token,
                          HttpSession session,
                          Model model) {
        ApprovalResult result = overrideService.approve(token, session.getId(), this::isYankeeWhite);

        switch (result) {
            case COMPLETE -> {
                model.addAttribute("complete", true);
                model.addAttribute("flag", FLAG);
            }
            case APPROVED -> {
                var status = overrideService.getStatus(token);
                model.addAttribute("token",     token);
                model.addAttribute("approvals", status != null ? status.approvals() : OverrideService.REQUIRED_APPROVALS - 1);
                model.addAttribute("required",  OverrideService.REQUIRED_APPROVALS);
                model.addAttribute("approved",  true);
            }
            case ALREADY_APPROVED -> {
                var status = overrideService.getStatus(token);
                model.addAttribute("token",         token);
                model.addAttribute("approvals",     status != null ? status.approvals() : 0);
                model.addAttribute("required",      OverrideService.REQUIRED_APPROVALS);
                model.addAttribute("alreadyApproved", true);
            }
            case EXPIRED       -> model.addAttribute("error", "Token expired.");
            case INVALID_TOKEN -> model.addAttribute("error", "Token invalid or expired.");
            case CANCELLED     -> model.addAttribute("error", "Override sequence terminated.");
        }

        return "override_approval";
    }

    private boolean isYankeeWhite(String sessionId) {
        var stored = sessionRepo.findById(sessionId);
        return stored != null && "YANKEE_WHITE".equals(stored.getAttribute("role"));
    }
}
