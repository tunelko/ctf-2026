package com.controlcenter.session;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class SecretSharing {

    public static final long PRIME = 0/*????_SECRET_CORRUPTED*/;

    public record Share(int x, long y) {}

    private SecretSharing() {}

    public static long[] generateCoefficients(long secret, int k, Random rng) {
        if (secret < 0 || secret >= PRIME) throw new IllegalArgumentException("Secret must be in [0, PRIME)");
        if (k < 2) throw new IllegalArgumentException("Threshold must be >= 2");
        long[] coeffs = new long[k];
        coeffs[0] = secret;
        for (int i = 1; i < k; i++) {
            coeffs[i] = (Math.abs(rng.nextLong()) % (PRIME - 1)) + 1;
        }
        return coeffs;
    }

    public static List<Share> fromCoefficients(long[] coeffs, int n) {
        if (n < coeffs.length) throw new IllegalArgumentException("n must be >= k");
        List<Share> shares = new ArrayList<>(n);
        for (int x = 1; x <= n; x++) {
            shares.add(new Share(x, evaluate(coeffs, x)));
        }
        return shares;
    }

    public static boolean verify(long[] coeffs, int x, long y) {
        return evaluate(coeffs, x) == y;
    }

    public static long evaluate(long[] coeffs, int x) {
        long y = 0;
        for (int i = coeffs.length - 1; i >= 0; i--) {
            y = (y * x + coeffs[i]) % PRIME;
        }
        return y;
    }

    public static List<Share> split(long secret, int n, int k, Random rng) {
        return fromCoefficients(generateCoefficients(secret, k, rng), n);
    }

    public static long reconstruct(List<Share> shares) {
        long secret = 0;
        /*<DATA_CORRUPTED>*/
        return secret;
    }
}
