package com.controlcenter.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

@Service
public class OverrideService {

    public static final int      REQUIRED_APPROVALS = 5;
    public static final Duration TTL                = Duration.ofMinutes(10);

    public enum ApprovalResult { INVALID_TOKEN, EXPIRED, ALREADY_APPROVED, APPROVED, COMPLETE, CANCELLED }

    public record OverrideStatus(String token, Instant expiresAt, int approvals, int required) {}

    private static final Logger log = LoggerFactory.getLogger(OverrideService.class);

    private final SecureRandom rng    = new SecureRandom();
    private final Map<String, State> active = new ConcurrentHashMap<>();

    private static final class State {
        final Instant    expiresAt;
        final Set<String> approvedSessionIds = ConcurrentHashMap.newKeySet();

        State(String initiatorId) {
            this.expiresAt = Instant.now().plus(TTL);
            this.approvedSessionIds.add(initiatorId);
        }

        boolean isExpired() { return Instant.now().isAfter(expiresAt); }
    }

    public String initiate(String initiatorSessionId) {
        byte[] bytes = new byte[16];
        rng.nextBytes(bytes);
        String token = bytesToHex(bytes);
        active.put(token, new State(initiatorSessionId));
        return token;
    }

    public ApprovalResult approve(String token, String sessionId, Predicate<String> isAuthorized) {
        State state = active.get(token);
        if (state == null) return ApprovalResult.INVALID_TOKEN;

        synchronized (state) {
            if (!active.containsKey(token))             return ApprovalResult.INVALID_TOKEN;
            if (state.isExpired())                      { active.remove(token); return ApprovalResult.EXPIRED; }
            if (state.approvedSessionIds.contains(sessionId)) return ApprovalResult.ALREADY_APPROVED;

            state.approvedSessionIds.add(sessionId);

            if (state.approvedSessionIds.size() >= REQUIRED_APPROVALS) {
                state.approvedSessionIds.forEach(id ->
                    log.info("checking session={} yankeeWhite={}", id, isAuthorized.test(id)));
                boolean allValid = state.approvedSessionIds.stream().allMatch(isAuthorized);
                active.remove(token);
                return allValid ? ApprovalResult.COMPLETE : ApprovalResult.CANCELLED;
            }
            return ApprovalResult.APPROVED;
        }
    }

    public OverrideStatus getStatus(String token) {
        State state = active.get(token);
        if (state == null || state.isExpired()) { active.remove(token); return null; }
        return new OverrideStatus(token, state.expiresAt, state.approvedSessionIds.size(), REQUIRED_APPROVALS);
    }

    public boolean cancel(String token) {
        return active.remove(token) != null;
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}