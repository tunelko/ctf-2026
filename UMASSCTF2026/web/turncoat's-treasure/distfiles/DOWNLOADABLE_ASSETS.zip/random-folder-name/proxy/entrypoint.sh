#!/bin/sh
set -e

mkdir -p /etc/nginx/ssl
openssl req -x509 -newkey rsa:2048 -nodes \
  -keyout /etc/nginx/ssl/key.pem \
  -out /etc/nginx/ssl/cert.pem \
  -days 3650 \
  -subj "/CN=instancer" \
  -addext "subjectAltName=DNS:${HOST},DNS:*.${HOST}"

envsubst '${HOST}' < /etc/nginx/conf.d/default.conf.template > /etc/nginx/conf.d/default.conf

exec nginx -g 'daemon off;'
