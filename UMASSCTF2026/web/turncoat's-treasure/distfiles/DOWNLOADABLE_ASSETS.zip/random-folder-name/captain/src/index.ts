import express from "express";
import puppeteer from "puppeteer";
import https from "https";
import fs from "fs";

const PORT = 80;
const HTTPS_PORT = 443;
const app = express();

app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'none'; refresh 'none'; base-uri 'none'; frame-ancestors 'none'");
  next();
});


app.get("/treasure", (req, res) => {
  const ip = req.socket.remoteAddress;
  if (ip !== "127.0.0.1" && ip !== "::1" && ip !== "::ffff:127.0.0.1") {
    res.status(403).send("Forbidden");
    return;
  }
  console.log("Somebody touched the treasure!");
  res.type("text/css").send("here is your treasure " + req.query.name + " UMASS{testing}");
});

app.get("/call-captain", async (req, res) => {
  const endpoint = typeof req.query.endpoint === "string" ? req.query.endpoint : "/login";
  const url = `https://forum.${process.env.HOST}${endpoint}`;
  res.send("Captain is visiting the forum...");
  console.log("Captain was called")
  // aye aye captain

  try {
    const b = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--ignore-certificate-errors"],
    });
    const ctx = await b.createBrowserContext();
    const page = await ctx.newPage();

    await page.goto(url, {
      waitUntil: "networkidle2",
      timeout: 20000,
    });

    await new Promise((r) => setTimeout(r, 240000));

    await b.close();
    console.log("Captain finished visiting forum");
  } catch (err) {
    console.error("Captain bot error:", err);
  }
});

app.listen(PORT, () => {
  console.log(`Captain server running on port ${PORT}`);
});

https.createServer({
  key: fs.readFileSync("/etc/ssl/captain/key.pem"),
  cert: fs.readFileSync("/etc/ssl/captain/cert.pem"),
}, app).listen(HTTPS_PORT, () => {
  console.log(`Captain HTTPS server running on port ${HTTPS_PORT}`);
});
