#!/bin/bash

solr start -c -p 8983

echo "Waiting for Solr to start..."
until curl -s "http://localhost:8983/solr/admin/info/system" | grep -q "lucene"; do
  sleep 2
done

echo "Solr is up. Creating collections..."

solr create_collection -c flights -rf 1
curl -X POST -H 'Content-Type: application/json' 'http://localhost:8983/solr/flights/update?commit=true' -d '[
  { "id": "1", "destination": "Reykjavík", "flight_no": "ECL-2026-Z", "status": "In Flight" },
  { "id": "2", "destination": "Dallas", "flight_no": "ECL-2026-B", "status": "Boarding" },
  { "id": "3", "destination": "Bilbao", "flight_no": "LFA-2026-54", "status": "Delayed" },
  { "id": "4", "destination": "Antarctica", "flight_no": "ECL-STRATO-1", "status": "Scheduled" }
]'

solr create_collection -c flag -rf 1

curl -X POST -H 'Content-Type: application/json' \
  'http://localhost:8983/solr/flag/update?commit=true' \
  -d "[
  {
    \"flag\": \"$FLAG\"
  }
]"

unset FLAG

echo "Provisioning complete. Stopping background Solr..."
solr stop -p 8983

echo "Starting Solr in foreground..."
exec solr -c -f
