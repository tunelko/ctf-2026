#!/bin/sh

export ADMIN_TOKEN=$(openssl rand -hex 32)

sed -i "s/REPLACE_ADMIN_TOKEN/$ADMIN_TOKEN/g" /app/templates/admin.html

exec "$@"
