const express = require('express');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT_PUBLIC = 5003;
const PORT_INTERNAL = 8080; 

const SOLR_HOST = process.env.SOLR_HOST || 'localhost';
const SOLR_PORT = process.env.SOLR_PORT || '5003';
const BASE_SOLR_URL = `http://${SOLR_HOST}:${SOLR_PORT}/solr`;
const BOT_SERVICE_URL = 'http://bot:3000/visit';

const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

app.use(bodyParser.json());
app.use(express.static('public'));

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'X-Auth, Content-Type');

    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

app.get('/admin.html', (req, res) => {
    if (req.socket.localPort !== PORT_INTERNAL) {
        return res.status(403).send(`<h1>403 Forbidden</h1>`);
    }

    res.sendFile(path.join(__dirname, 'templates', 'admin.html'));
});

app.post('/api/report', async (req, res) => {
    const { url } = req.body;
    if (!url || typeof url !== 'string') return res.status(400).send('Missing URL');
    
    try {
        const botResponse = await fetch(BOT_SERVICE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url })
        });
        if (botResponse.ok) res.send('Admin notified');
        else res.status(500).send('Admin is busy');
    } catch (error) {
        console.error('Bot Connection Error:', error);
        res.status(500).send('Failed to contact admin bot');
    }
});

app.get('/api/public/flights', async (req, res) => {
    try {
        const queryUrl = `${BASE_SOLR_URL}/flights/select?q=*:*&rows=10&wt=json`;
        
        const response = await fetch(queryUrl);
        const text = await response.text();
        
        try {
            const data = JSON.parse(text);
            res.json(data);
        } catch (e) {
            res.send(text);
        }
    } catch (error) {
        console.error("Flight fetch error:", error);
        res.status(500).send('System Error');
    }
});

app.get('/api/admin/search', async (req, res) => {
    
    if (req.socket.localPort !== PORT_INTERNAL) {
        return res.status(403).send(`<h1>403 Forbidden</h1>`);
    }

    try {
        const query = req.query.q || '*:*';
        const authHeader = req.get('X-Auth');
        
        if (!authHeader || authHeader !== ADMIN_TOKEN) {
             return res.status(403).json({ error: 'Access denied' });
        }

        if (/[\?&]collection/i.test(query)) {
            return res.status(400).json({ error: 'Illegal parameter' });
        }

        const queryUrl = `${BASE_SOLR_URL}/flights/select?q=${query}&df=destination&rows=10`;
        const response = await fetch(queryUrl);
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            res.json(data);
        } catch (e) {
            res.send(text);
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('System Error');
    }
});

app.listen(PORT_PUBLIC, () => console.log(`Public Server running on port ${PORT_PUBLIC}`));
app.listen(PORT_INTERNAL, () => console.log(`Internal Admin Server running on port ${PORT_INTERNAL}`));
