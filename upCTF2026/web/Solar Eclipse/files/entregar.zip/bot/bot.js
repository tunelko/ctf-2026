const express = require('express');
const puppeteer = require('puppeteer');

const app = express();
app.use(express.json());

const PORT = 3000;

app.post('/visit', async (req, res) => {
    const url = req.body.url;
    if (!url || !url.startsWith('http')) {
        return res.status(400).send('Invalid URL');
    }

    try {
        const browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/google-chrome',
            args: [
                '--no-sandbox',
                '--disable-gpu',
                '--disable-dev-shm-usage'
            ]
        });

        const page = await browser.newPage();
        
        await page.goto(url, { waitUntil: 'networkidle0', timeout: 5000 });
        await new Promise(r => setTimeout(r, 5000));

        await browser.close();
        res.send('Visited!');
    } catch (e) {
        console.error(e);
        res.status(500).send('Error visiting page');
    }
});

app.listen(PORT, () => console.log(`Bot listening on port ${PORT}`));
