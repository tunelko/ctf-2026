#!/bin/bash


export PATH="/usr/bin:/bin"

echo "--- NSJAIL SYMBOLIC INTERFACE ---"
echo "Only symbols allowed. Direct redirection (>) is disabled at kernel level."

while true; do
    printf ">> "
    if ! read -r input; then break; fi

    if [[ "$input" =~ [a-z0-9A-Z] ]]; then
        echo "FAIL: Alphanumeric characters detected."
        continue
    fi

    if [[ "$input" == *">"* ]]; then
        echo "FAIL: Direct redirection is forbidden."
        continue
    fi

    # 3. Ejecución controlada
    eval "$input"



done
