sudo docker rm -f my-extreme-challenge
sudo docker build -t extreme-jail .
sudo docker run -d --privileged -p 1337:1337 --name my-extreme-challenge extreme-jail
