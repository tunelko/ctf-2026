import puppeteer from "puppeteer";

export const challenge = {
  name: "seeknbank",
  appUrl: new URL("http://web:5000/"),
};

export const flag = {
  value: process.env.FLAG
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const visit = async (url) => {
  console.log(`start: ${url}`);

  const browser = await puppeteer.launch({
    headless: true,
    executablePath: "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--disable-popup-blocking",
      "--js-flags=--noexpose_wasm,--jitless",
      "--disable-features=HttpsFirstBalancedModeAutoEnable",
    ],
  });

  const context = await browser.createBrowserContext();

  try {
    // Create a flag note
    const page1 = await context.newPage();
    await page1.goto(challenge.appUrl, { timeout: 3_000 });
    await page1.waitForSelector("input[name='name']");
    await page1.type("input[name='name']", flag.value);
    await page1.click("button[type='submit']");
    await sleep(1_000);

    const cookies = await page1.cookies(); 
    await page1.close();
    const page2 = await context.newPage();
    // Visit the given URL
    await page2.goto(url, { timeout: 3_000 });
    await sleep(10_000);
    await page2.close();
  } catch (e) {
    console.error(e);
  }

  await context.close();
  await browser.close();

  console.log(`end: ${url}`);
};
