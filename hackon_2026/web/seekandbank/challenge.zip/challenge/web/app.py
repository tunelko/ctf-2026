from flask import Flask, render_template, request, redirect, url_for, session, make_response
from flask_wtf.csrf import CSRFProtect
from flask_session import Session
import os
import logging

app = Flask(__name__)
app.logger.setLevel(logging.INFO)
app.config['SECRET_KEY'] = os.urandom(24).hex()

app.config['SESSION_TYPE'] = 'filesystem'
Session(app) 

csrf = CSRFProtect(app)

@app.after_request
def add_header(response):
    response.headers['Cache-Control'] = 'public, max-age=3600'
    response.headers.pop('Vary', None)
    return response

@app.route('/')
def index():
    if 'accounts' not in session:
        session['accounts'] = []
    
    query = request.args.get('q', '')
    user_accounts = session.get('accounts', [])

    app.logger.info(f"Cookies received: {dict(request.cookies)}")

    if query:
        results = [account for account in user_accounts if query in account]
    else:
        results = user_accounts
        
    content = render_template('index.html', results=results, query=query)
    resp = make_response(content + (""))
    return resp

@app.route('/add', methods=['POST'])
def add():
    new_item = request.form.get('name')
    
    if new_item:
        if 'accounts' not in session:
            session['accounts'] = []
        
        session['accounts'].append(new_item)
        session.modified = True
        
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True)